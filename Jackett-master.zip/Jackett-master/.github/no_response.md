Hi @{{ payload.data.user.login }},

No response has been received for {{ days }} days. To prevent issue tracker clutter, this issue will now be closed. To re-open the issue, please provide the information requested and the issue will automatically re-open.
