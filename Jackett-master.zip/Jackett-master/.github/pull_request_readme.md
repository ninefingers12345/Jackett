Hi @{{ payload.pull_request.user.login }},

Thanks for your contribution to Jackett!

If you are adding a new indexer, please ensure that you've added it to the readme as well

A human will be along soon to review
